(function(){
  'use strict';

  /* ---------- koruma: sağ tık, kopyalama, kaynak ve geliştirici araçları kısayolları ---------- */
  var isField=function(e){return e.target&&e.target.closest&&e.target.closest('input,textarea,[contenteditable="true"]');};
  document.addEventListener('contextmenu',function(e){e.preventDefault();});
  ['copy','cut','dragstart','selectstart'].forEach(function(ev){
    document.addEventListener(ev,function(e){if(!isField(e))e.preventDefault();});
  });
  window.addEventListener('keydown',function(e){
    var k=(e.key||'').toLowerCase(),mod=e.ctrlKey||e.metaKey;
    var block=k==='f12'
      ||(mod&&e.shiftKey&&['i','j','c','k','e','m'].indexOf(k)>-1)
      ||(mod&&e.altKey&&['i','j','c','u'].indexOf(k)>-1)
      ||(mod&&['u','s','p'].indexOf(k)>-1)
      ||(mod&&['c','x','a'].indexOf(k)>-1&&!isField(e));
    if(block){e.preventDefault();e.stopPropagation();}
  },true);
  try{
    var noop=function(){};
    ['log','debug','info','warn','error','table','dir','dirxml','trace','group','groupCollapsed','groupEnd','count','time','timeEnd','timeLog','assert']
      .forEach(function(m){try{console[m]=noop;}catch(_){}});
  }catch(_){}

  /* ---------- yardımcılar ---------- */
  var RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  var root=document.documentElement,hdr=document.querySelector('.hdr'),progBar=document.querySelector('.prog');
  if(!RM&&'IntersectionObserver' in window)root.classList.add('js');
  var clamp=function(x,a,b){return Math.min(b===undefined?1:b,Math.max(a===undefined?0:a,x));};
  var p=function(t,s,d){return clamp((t-s)/d);};
  var eo=function(x){return 1-Math.pow(1-x,4);};
  var eio=function(x){return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2;};
  var eback=function(x){var c1=1.70158,c3=c1+1;return x<=0?0:1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2);};
  var lerp=function(a,b,x){return a+(b-a)*x;};
  var NS='http://www.w3.org/2000/svg';
  function el(tag,attrs,parent){var n=document.createElementNS(NS,tag);for(var k in attrs)n.setAttribute(k,attrs[k]);if(parent)parent.appendChild(n);return n;}
  function setScale(n,cx,cy,s){n.setAttribute('transform','translate('+cx+' '+cy+') scale('+s+') translate('+(-cx)+' '+(-cy)+')');}

  /* ---------- menü ---------- */
  var menu=document.getElementById('menu'),openBtn=document.querySelector('.hdr .menu-btn');
  function setMenu(open){
    menu.hidden=!open;openBtn.setAttribute('aria-expanded',open?'true':'false');
    document.documentElement.classList.toggle('lock',open);
    if(open){menu.querySelector('[data-close]').focus();}else{openBtn.focus({preventScroll:true});}
  }
  openBtn.addEventListener('click',function(){setMenu(true);});
  menu.addEventListener('click',function(e){if(e.target.closest('[data-close],a'))setMenu(false);});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!menu.hidden)setMenu(false);});

  /* ---------- çizgi: logodaki harf kalınlığında, kaydırdıkça çizilir ---------- */
  function rpath(pts,R){
    var d='M'+pts[0][0].toFixed(1)+','+pts[0][1].toFixed(1);
    for(var i=1;i<pts.length-1;i++){
      var a=pts[i-1],b=pts[i],c=pts[i+1];
      var v1=[b[0]-a[0],b[1]-a[1]],v2=[c[0]-b[0],c[1]-b[1]];
      var l1=Math.hypot(v1[0],v1[1]),l2=Math.hypot(v2[0],v2[1]);
      var r=Math.min(R,l1/2,l2/2);
      var s=[b[0]-v1[0]/l1*r,b[1]-v1[1]/l1*r],e=[b[0]+v2[0]/l2*r,b[1]+v2[1]/l2*r];
      var sweep=(v1[0]*v2[1]-v1[1]*v2[0])>0?1:0;
      d+=' L'+s[0].toFixed(1)+','+s[1].toFixed(1)+' A'+r.toFixed(1)+','+r.toFixed(1)+' 0 0 '+sweep+' '+e[0].toFixed(1)+','+e[1].toFixed(1);
    }
    var z=pts[pts.length-1];
    return d+' L'+z[0].toFixed(1)+','+z[1].toFixed(1);
  }
  var lines=[].map.call(document.querySelectorAll('svg.line'),function(svg){
    return {svg:svg,path:svg.querySelector('path'),shape:svg.dataset.shape,mode:svg.dataset.mode||'scroll',len:0,prog:0};
  });
  function buildLines(){
    lines.forEach(function(l){
      var r=l.svg.getBoundingClientRect(),W=r.width,H=r.height;if(!W||!H)return;
      var s=clamp(W*0.034,16,44),R=Math.min(110,W*0.11),yL=H-s/2,yH=s/2,pts;
      if(l.shape==='frame'){
        var m=clamp(W*0.06,30,96);
        yL=H-m;
        pts=[[-s,yL],[W-m,yL],[W-m,-s]];
      }else{
        if(l.shape==='arch')pts=[[-s,yL],[W*0.26,yL],[W*0.26,yH],[W*0.64,yH],[W*0.64,yL],[W+s,yL]];
        else if(l.shape==='down')pts=[[-s,yH],[W*0.58,yH],[W*0.58,yL],[W+s,yL]];
        else{var ym=(yL+yH)/2;pts=[[-s,yL],[W*0.31,yL],[W*0.31,ym],[W*0.65,ym],[W*0.65,yH],[W+s,yH]];R=Math.min(R,(yL-yH)/4);}
      }
      l.svg.setAttribute('viewBox','0 0 '+W+' '+r.height);
      l.path.setAttribute('stroke-width',s);
      l.path.setAttribute('d',rpath(pts,R));
      l.len=l.path.getTotalLength();
      l.path.setAttribute('stroke-dasharray',l.len+' '+l.len);
    });
    drawLines();
  }
  var loadStart=null;
  function drawLines(){
    var vh=window.innerHeight,atEnd=window.scrollY+vh>=document.documentElement.scrollHeight-4;
    lines.forEach(function(l){
      if(!l.len)return;var pr;
      if(RM)pr=1;
      else if(l.mode==='load')pr=l.prog;
      else{
        var r=l.svg.getBoundingClientRect();
        var D=l.shape==='frame'?Math.min(r.height,vh*0.8):vh*0.5;
        pr=clamp((vh*0.94-r.top)/D);
        if(atEnd&&r.top<vh)pr=1;
      }
      l.path.setAttribute('stroke-dashoffset',(l.len*(1-pr)).toFixed(1));
    });
  }
  function loadTick(now){
    if(loadStart===null)loadStart=now;
    var x=eio(p((now-loadStart)/1000,0.35,1.5));
    lines.forEach(function(l){if(l.mode==='load')l.prog=x;});
    drawLines();
    if(x<1)requestAnimationFrame(loadTick);
  }
  var ticking=false;
  /* süreç: sabitlenen bölümde dikey kaydırma, adımları yana akıtır */
  var hs=document.querySelector('.hs'),hsPin=hs.querySelector('.hs-pin'),hsTrack=hs.querySelector('.hs-track'),hsLine=hs.querySelector('.hs-line'),hsDist=0,hsTop=0;
  function buildHS(){
    root.style.setProperty('--hdr',hdr.offsetHeight+'px');
    if(RM)return;
    hs.classList.add('hs-on');
    var pinH=hsPin.clientHeight,tw=hsTrack.scrollWidth,vw=hs.clientWidth;
    hsDist=Math.max(0,tw-vw);hsTop=parseFloat(getComputedStyle(hsPin).top)||0;
    hs.style.setProperty('--hs-h',(pinH+hsDist)+'px');
    var s=clamp(vw*0.034,16,44),st=clamp(pinH*0.085,38,84),y0=pinH-s/2-pinH*0.07;
    var pts=[[-s,y0]],y=y0;
    [].forEach.call(hs.querySelectorAll('.hs-step'),function(pn){var x=pn.offsetLeft-Math.min(40,vw*0.05);pts.push([x,y]);y-=st;pts.push([x,y]);});
    pts.push([tw+s,y]);
    hsLine.setAttribute('width',tw);hsLine.setAttribute('height',pinH);hsLine.setAttribute('viewBox','0 0 '+tw+' '+pinH);
    var pth=hsLine.querySelector('path');pth.setAttribute('stroke-width',s);pth.setAttribute('d',rpath(pts,st/2));
    drawHS();
  }
  function drawHS(){
    if(RM||!hsDist){hsTrack.style.transform='';return;}
    var pr=clamp((hsTop-hs.getBoundingClientRect().top)/hsDist);
    hsTrack.style.transform='translate3d('+(-pr*hsDist).toFixed(1)+'px,0,0)';
  }
  function drawProg(){
    var max=root.scrollHeight-window.innerHeight;
    progBar.style.transform='scaleX('+(max>0?clamp(window.scrollY/max):0).toFixed(4)+')';
  }
  function onScroll(){if(ticking)return;ticking=true;requestAnimationFrame(function(){ticking=false;drawLines();drawHS();drawProg();});}
  function rebuild(){buildHS();buildLines();drawProg();}
  window.addEventListener('scroll',onScroll,{passive:true});
  window.addEventListener('resize',rebuild);
  if(window.ResizeObserver)new ResizeObserver(rebuild).observe(document.body);
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(rebuild);
  rebuild();

  /* markalar: kesintisiz kayan şerit */
  (function(){
    var mq=document.querySelector('.marq'),tr=mq.querySelector('.marq-track');if(RM)return;
    mq.classList.add('run');
    var base=[].slice.call(tr.children),guard=0;
    function add(list){list.forEach(function(c){var k=c.cloneNode(true);k.setAttribute('aria-hidden','true');tr.appendChild(k);});}
    while(tr.scrollWidth<2800&&guard++<10)add(base);
    add([].slice.call(tr.children));
    tr.style.setProperty('--dur',(tr.scrollWidth/2/60).toFixed(1)+'s');
  })();

  /* blog: yana kaydırma ve okuma paneli */
  (function(){
    var row=document.getElementById('blogRow'),btns=[].slice.call(document.querySelectorAll('.blog-nav .rbtn'));
    function step(){var c=row.querySelector('.post');return c.getBoundingClientRect().width+parseFloat(getComputedStyle(row).columnGap||0);}
    function sync(){var max=row.scrollWidth-row.clientWidth-2;btns[0].disabled=row.scrollLeft<=2;btns[1].disabled=row.scrollLeft>=max;}
    btns.forEach(function(b){b.addEventListener('click',function(){row.scrollBy({left:step()*(+b.dataset.dir),behavior:RM?'auto':'smooth'});});});
    row.addEventListener('scroll',sync,{passive:true});window.addEventListener('resize',sync);sync();
    var dlg=document.getElementById('reader'),rTag=document.getElementById('readerTag'),rTitle=document.getElementById('readerTitle'),rMeta=document.getElementById('readerMeta'),rCont=document.getElementById('readerContent'),lastBtn=null;
    [].forEach.call(document.querySelectorAll('.post'),function(post){
      var body=post.querySelector('.post-body'),words=body.textContent.trim().split(/\s+/).length,mins=Math.max(1,Math.round(words/180));
      post.querySelector('.mins').textContent=mins+' dk okuma';
      post.querySelector('.read').addEventListener('click',function(e){
        lastBtn=e.currentTarget;
        rTag.textContent=post.querySelector('.tag').textContent;rTitle.textContent=post.querySelector('h3').textContent;rMeta.textContent=mins+' dk okuma';
        while(rCont.firstChild)rCont.removeChild(rCont.firstChild);
        [].forEach.call(body.children,function(n){rCont.appendChild(n.cloneNode(true));});
        if(dlg.showModal)dlg.showModal();else dlg.setAttribute('open','');
        dlg.scrollTop=0;root.classList.add('lock');
      });
    });
    function closeR(){if(dlg.close)dlg.close();else dlg.removeAttribute('open');}
    dlg.addEventListener('close',function(){root.classList.remove('lock');if(lastBtn)lastBtn.focus({preventScroll:true});});
    dlg.addEventListener('click',function(e){if(e.target===dlg||e.target.closest('[data-close-reader]'))closeR();});
  })();

  /* kaydırınca beliren öğeler */
  (function(){
    var els=[].slice.call(document.querySelectorAll('.rv'));
    if(!root.classList.contains('js'))return;
    els.forEach(function(e){var sib=[].filter.call(e.parentNode.children,function(c){return c.classList.contains('rv');});e.style.setProperty('--i',Math.min(sib.indexOf(e),4));});
    var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target);}});},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
    els.forEach(function(e){io.observe(e);});
  })();
  if(!RM)requestAnimationFrame(loadTick);

  /* ---------- sorunların üstünü çiz ---------- */
  var probs=document.getElementById('probs');
  if(RM||!('IntersectionObserver' in window))probs.classList.add('struck');
  else new IntersectionObserver(function(es,o){es.forEach(function(e){if(e.isIntersecting){probs.classList.add('struck');o.disconnect();}});},{threshold:.6}).observe(probs);

  /* ---------- hizmet çizimleri ---------- */
  function mkGrid(svg){
    var S=116,G=26,items=[],order=[1,5,7,3],beats=[1.5,2.0,2.5,3.0];
    for(var i=0;i<9;i++){
      var x=(i%3)*(S+G),y=Math.floor(i/3)*(S+G),g=el('g',{},svg),fill=null;
      if(i%2===0){
        el('rect',{x:x,y:y,width:S,height:S,rx:24,'class':'c-fg'},g);
        if(i===0)el('circle',{cx:x+58,cy:y+58,r:28,'class':'c-bg'},g);
        if(i===2){el('rect',{x:x+26,y:y+34,width:64,height:15,rx:7.5,'class':'c-bg'},g);el('rect',{x:x+26,y:y+60,width:42,height:15,rx:7.5,'class':'c-bg'},g);}
        if(i===4)el('rect',{x:x+26,y:y+26,width:64,height:64,rx:16,'class':'c-blue'},g);
        if(i===6)el('circle',{cx:x+58,cy:y+58,r:23,'class':'c-bgring'},g);
        if(i===8)el('path',{d:'M'+(x+26)+','+(y+58)+' h64 a32,32 0 0 1 -64,0 z','class':'c-bg'},g);
      }else{
        el('rect',{x:x+3,y:y+3,width:S-6,height:S-6,rx:21,'class':'c-out'},g);
        fill=el('rect',{x:x,y:y,width:S,height:S,rx:24,'class':'c-blue'},g);
      }
      items.push({g:g,cx:x+S/2,cy:y+S/2,fill:fill});
    }
    return function(t){
      var out=1-eio(p(t,6.2,.5));
      items.forEach(function(it,i){
        var sc=eback(p(t,.2+i*.07,.45))*out,k=order.indexOf(i);
        if(k>-1){var f=p(t,beats[k],.35);sc*=1+.1*Math.sin(Math.PI*f);setScale(it.fill,it.cx,it.cy,eo(f));}
        setScale(it.g,it.cx,it.cy,sc);
      });
    };
  }
  function mkPhone(svg){
    var g=el('g',{},svg);
    var body=el('rect',{x:80,y:20,width:240,height:440,rx:46,'class':'c-stroke','stroke-width':14},g);
    var L=body.getTotalLength();body.setAttribute('stroke-dasharray',L+' '+L);
    var head=el('rect',{x:106,y:48,width:188,height:0,rx:22,'class':'c-blue'},g);
    var l1=el('rect',{x:106,y:204,width:0,height:18,rx:9,'class':'c-fg'},g);
    var l2=el('rect',{x:106,y:236,width:0,height:18,rx:9,'class':'c-fg'},g);
    var btn=el('rect',{x:106,y:372,width:188,height:58,rx:29,'class':'c-fg'},g);
    var rip=el('circle',{cx:200,cy:401,r:0,'class':'c-ring'},g);
    var cur=el('circle',{r:15,'class':'c-cur'},g);
    var taps=[2.3,3.0,3.7];
    return function(t){
      g.setAttribute('opacity',1-eio(p(t,6.2,.5)));
      body.setAttribute('stroke-dashoffset',L*(1-eio(p(t,.2,.9))));
      head.setAttribute('height',130*eo(p(t,1.0,.5)));
      l1.setAttribute('width',188*eo(p(t,1.2,.5)));
      l2.setAttribute('width',126*eo(p(t,1.3,.5)));
      var press=0,rp=0,ro=0;
      taps.forEach(function(tt){var q=p(t,tt,.25);if(q>0&&q<1)press=Math.sin(Math.PI*q);var r=p(t,tt,.55);if(r>0&&r<1){rp=r;ro=1-r;}});
      setScale(btn,200,401,eback(p(t,1.5,.45))*(1-.06*press));
      rip.setAttribute('r',16+eo(rp)*80);rip.setAttribute('opacity',ro);
      var cm=eo(p(t,1.8,.4));
      cur.setAttribute('cx',lerp(330,212,cm));cur.setAttribute('cy',lerp(500,408,cm));
      cur.setAttribute('r',Math.max(0,15*eback(p(t,1.75,.3))*(1-.2*press)));
    };
  }
  function mkBars(svg){
    var BH=[78,130,188,255,320],X=function(i){return i*85;},bars=[];
    function bp(x,h){var r=Math.min(30,h);return 'M'+x+',400 V'+(400-h+r)+' a'+r+','+r+' 0 0 1 '+r+','+(-r)+' h'+(60-2*r)+' a'+r+','+r+' 0 0 1 '+r+','+r+' V400 Z';}
    for(var i=0;i<5;i++)bars.push(el('path',{'class':i===4?'c-blue':'c-fg'},svg));
    var ring=el('circle',{r:0,'class':'c-ringfg'},svg),dot=el('circle',{r:17,'class':'c-fg'},svg);
    var pos=function(i){return [X(i)+30,400-BH[i]-27];},lands=[1.7,2.2,2.7,3.2];
    return function(t){
      var out=1-eio(p(t,6.2,.5));
      bars.forEach(function(b,i){b.setAttribute('d',bp(X(i),Math.max(.01,BH[i]*eo(p(t,.2+i*.1,.8))*out)));});
      var seg=0,e=0;lands.forEach(function(Ld,k){var q=p(t,Ld-.36,.36);if(q>0){seg=k;e=q;}});
      var a=pos(seg),b=pos(seg+1),ex=eio(e);
      dot.setAttribute('cx',lerp(a[0],b[0],ex));dot.setAttribute('cy',lerp(a[1],b[1],ex)-46*Math.sin(Math.PI*e));
      dot.setAttribute('r',Math.max(0,17*eback(p(t,1.0,.35))*out));
      var r=p(t,3.2,.7),lp=pos(4);
      ring.setAttribute('cx',lp[0]);ring.setAttribute('cy',lp[1]);ring.setAttribute('r',20+eo(r)*52);ring.setAttribute('opacity',(r>0&&r<1)?1-r:0);
    };
  }
  var LOOP=7;
  var ills=[['ill-grid',mkGrid],['ill-phone',mkPhone],['ill-bars',mkBars]].map(function(d){
    var svg=document.getElementById(d[0]);return {svg:svg,draw:d[1](svg),on:false,t0:null};
  });
  if(RM||!('IntersectionObserver' in window)){ills.forEach(function(i){i.draw(5);});}
  else{
    ills.forEach(function(i){i.draw(0);});
    var io=new IntersectionObserver(function(es){es.forEach(function(e){
      var it=ills.filter(function(i){return i.svg===e.target;})[0];it.on=e.isIntersecting;
      if(it.on&&it.t0===null)it.t0=performance.now();
      if(it.on)kick();
    });},{threshold:.35});
    ills.forEach(function(i){io.observe(i.svg);});
    var running=false;
    function frame(now){
      var any=false;
      ills.forEach(function(i){if(i.on){any=true;i.draw(((now-i.t0)/1000)%LOOP);}});
      if(any)requestAnimationFrame(frame);else running=false;
    }
    function kick(){if(!running){running=true;requestAnimationFrame(frame);}}
  }
})();
